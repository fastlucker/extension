import ImageIcon from './ImageIcon'

export default ImageIcon
